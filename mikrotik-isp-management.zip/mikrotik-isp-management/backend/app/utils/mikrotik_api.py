from routeros_api import RouterOsApiPool
from app.config import settings

class MikroTikAPI:
    def __init__(self):
        self.pool = RouterOsApiPool(
            host=settings.MIKROTIK_HOST,
            username=settings.MIKROTIK_USER,
            password=settings.MIKROTIK_PASS,
            plaintext_login=True
        )
    
    def create_voucher(self, code: str, duration: int):
        with self.pool.get_api() as api:
            api.get_resource('/ip/hotspot/user').add(
                name=code,
                password=code,
                profile=f"{duration}h"
            )