import os
from pydantic import BaseSettings

class Settings(BaseSettings):
    DATABASE_URL: str = os.getenv("DATABASE_URL")
    JWT_SECRET: str = os.getenv("JWT_SECRET")
    MIKROTIK_HOST: str = os.getenv("MIKROTIK_HOST")
    MIKROTIK_USER: str = os.getenv("MIKROTIK_USER")
    MIKROTIK_PASS: str = os.getenv("MIKROTIK_PASS")

    class Config:
        env_file = ".env"

settings = Settings()