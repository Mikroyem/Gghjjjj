# نظام إدارة MikroTik ISP

## المتطلبات
- Docker
- Node.js 16+
- Python 3.10+

## التنصيب
1. انسخ ملف البيئة:
```bash
cp .env.example .env