import React, { useState, useEffect } from 'react';
import { Table, Button, Modal } from 'antd';
import axios from 'axios';

const VoucherManager = () => {
    const [vouchers, setVouchers] = useState([]);
    
    useEffect(() => {
        axios.get('/api/vouchers')
            .then(res => setVouchers(res.data))
    }, []);

    const columns = [
        { title: 'الكود', dataIndex: 'code' },
        { title: 'المدة', dataIndex: 'duration' },
        { title: 'السعر', dataIndex: 'price' },
        {
            title: 'الإجراءات',
            render: (_, record) => (
                <Button onClick={() => window.print()}>
                    طباعة
                </Button>
            )
        }
    ];

    return <Table columns={columns} dataSource={vouchers} />;
};